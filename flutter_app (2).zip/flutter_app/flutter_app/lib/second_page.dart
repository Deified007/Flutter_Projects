import 'dart:ui';

import 'package:flutter/material.dart';

class SecondPage extends StatefulWidget {
  const SecondPage({super.key});

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: 844,
        decoration: BoxDecoration(
          color: Color(0xff429690),
        ),
        child: Stack(
          children: [
            Positioned(
              left: 0,
              top: 347,
              child: Opacity(
                opacity: 0.2,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 60,
                    sigmaY: 60,
                  ),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(18, 149, 18, 149),
                    width: 430,
                    height: 585,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.cover,
                        image: NetworkImage(""),
                      ),
                    ),
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 39, 237),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom(
                          padding: EdgeInsets.zero,
                        ),
                        child: ClipRect(
                          child: BackdropFilter(
                            filter: ImageFilter.blur(
                              sigmaX: 45,
                              sigmaY: 45,
                            ),
                            child: Container(
                              padding:
                                  EdgeInsets.fromLTRB(144.5, 13, 133.5, 13),
                              width: 355,
                              height: 50,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                border: Border(),
                                gradient: LinearGradient(
                                  begin: Alignment(-1, -1),
                                  end: Alignment(1.068, 1),
                                  colors: <Color>[
                                    Color(0xffd4bc78),
                                    Color(0xffcfa01c)
                                  ],
                                  stops: <double>[0, 1],
                                ),
                              ),
                              child: Container(
                                width: double.infinity,
                                height: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Center(
                                      child: Container(
                                        margin:
                                            EdgeInsets.fromLTRB(0, 0, 11, 0),
                                        child: Text(
                                          'Login',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            height: 0.75,
                                            color: Color(0xffe1fae5),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 32,
              top: 20,
              child: Container(
                width: 327.26,
                height: 16,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 244.44, 0),
                      child: Text(
                        '9:41',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          height: 1.2575,
                          letterSpacing: -0.2399999946,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 1, 0, 3),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 4.17, 0),
                            width: 15.37,
                            height: 10,
                            child: Image.network(""),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 1.68, 0.5),
                            width: 13.09,
                            height: 10,
                            child: Image.network(""),
                          ),
                          Container(
                            width: 26.5,
                            height: 12,
                            child: Image.network(""),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 17,
              top: 161,
              child: Container(
                width: 355,
                height: 337,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 74.5),
                      child: Text(
                        'Login',
                        style: TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.w400,
                          height: 1,
                          letterSpacing: -1.6,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 44),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 29.5),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(8, 0, 0, 1.5),
                                  child: Text(
                                    'Email',
                                    style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w700,
                                      height: 1.2125,
                                      letterSpacing: 0.15,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.fromLTRB(
                                      22.4, 19.8, 182, 18.6),
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: Color(0xffdbebd8),
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        margin:
                                            EdgeInsets.fromLTRB(0, 0, 13.4, 0),
                                        width: 19.2,
                                        height: 15.6,
                                        child: Image.network(""),
                                      ),
                                      Container(
                                        margin:
                                            EdgeInsets.fromLTRB(0, 0, 0, 1.2),
                                        child: Text(
                                          'Enter your email address',
                                          style: TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2125,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(8, 0, 0, 1.5),
                                  child: Text(
                                    'Password',
                                    style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w700,
                                      height: 1.2125,
                                      letterSpacing: 0.15,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  padding:
                                      EdgeInsets.fromLTRB(25, 18, 34.05, 18),
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: Color(0xffdbebd8),
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        margin:
                                            EdgeInsets.fromLTRB(0, 0, 16, 0),
                                        width: 14,
                                        height: 18,
                                        child: Image.network(""),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(
                                            0, 0, 152.05, 0),
                                        child: Text(
                                          'Enter your password',
                                          style: TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2125,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Opacity(
                                        opacity: 0.5,
                                        child: Container(
                                          margin:
                                              EdgeInsets.fromLTRB(0, 0, 0, 0),
                                          width: 15.9,
                                          height: 11.67,
                                          child: Image.network(""),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 97.5,
              top: 592,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 195,
                    height: 14,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                      ),
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            height: 1.2727272727,
                            color: Color(0xffffffff),
                          ),
                          children: [
                            TextSpan(
                              text: 'Don’t have an account yet?    ',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                                height: 1.2727272727,
                                color: Color(0xffffffff),
                              ),
                            ),
                            TextSpan(
                              text: 'Sign Up',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                height: 1.1666666667,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
