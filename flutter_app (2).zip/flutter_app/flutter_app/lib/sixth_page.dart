import 'dart:ui';

import 'package:flutter/material.dart';

class SixthPage extends StatefulWidget {
  const SixthPage({super.key});

  @override
  State<SixthPage> createState() => _SixthPageState();
}

class _SixthPageState extends State<SixthPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // incomewaF (108:235)
        width: double.infinity,
        height: 844,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // group412Lo (222:219)
              left: 0,
              top: 0,
              child: Container(
                width: 457,
                height: 866,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group37Kqh (222:214)
                      margin: EdgeInsets.fromLTRB(0, 0, 12, 17),
                      width: 445,
                      height: 309,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: NetworkImage(""),
                        ),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // rectangle24oks (137:1762)
                            left: 9,
                            top: 137,
                            child: Align(
                              child: SizedBox(
                                width: 374,
                                height: 48,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(40),
                                    color: Color(0xffcddcda),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // frame21uZ1 (137:1763)
                            left: 196,
                            top: 141,
                            child: Container(
                              width: 180,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Color(0xffffffff),
                                borderRadius: BorderRadius.circular(40),
                              ),
                              child: Center(
                                child: Text(
                                  'Income',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2125,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // expense9TM (137:1765)
                            left: 60,
                            top: 149,
                            child: Align(
                              child: SizedBox(
                                width: 84,
                                height: 25,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom(
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Text(
                                    'Expense',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w700,
                                      height: 1.2125,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group6DTD (109:3079)
                            left: 0,
                            top: 0,
                            child: Align(
                              child: SizedBox(
                                width: 267,
                                height: 219,
                                child: Image.network(""),
                              ),
                            ),
                          ),
                          Positioned(
                            // iconchevronleftL23 (108:238)
                            left: 24,
                            top: 81,
                            child: Align(
                              child: SizedBox(
                                width: 28,
                                height: 28,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom(
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.network(""),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group38ckF (222:216)
                      margin: EdgeInsets.fromLTRB(92, 0, 42, 35),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // categorywGj (109:3067)
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 9),
                            child: Text(
                              'CATEGORY',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                height: 1.2125,
                                letterSpacing: 0.96,
                                color: Color(0xff222222),
                              ),
                            ),
                          ),
                          Container(
                            // autogroup1jj3EWj (YLEBv7PRXgxHVVgRC31JJ3)
                            margin: EdgeInsets.fromLTRB(5, 0, 0, 0),
                            width: 318,
                            height: 50,
                            child: Stack(
                              children: [
                                Positioned(
                                  // tradingxSj (109:3063)
                                  left: 21,
                                  top: 16,
                                  child: Align(
                                    child: SizedBox(
                                      width: 57,
                                      height: 20,
                                      child: Text(
                                        'Trading',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125,
                                          letterSpacing: -0.16,
                                          color: Color(0xff222222),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // rectangle223DH (109:3065)
                                  left: 0,
                                  top: 0,
                                  child: Align(
                                    child: SizedBox(
                                      width: 318,
                                      height: 50,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          border: Border.all(
                                              color: Color(0xffdddddd)),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group39w3m (222:217)
                      margin: EdgeInsets.fromLTRB(92, 0, 41, 24),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroups37dF4T (YLEBh7m5G6ynw6DXB9s37D)
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                            width: 78,
                            height: 20,
                            child: Stack(
                              children: [
                                Positioned(
                                  // amountmoV (108:248)
                                  left: 0,
                                  top: 0,
                                  child: Align(
                                    child: SizedBox(
                                      width: 78,
                                      height: 20,
                                      child: Text(
                                        'AMOUNT',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125,
                                          letterSpacing: 0.96,
                                          color: Color(0xff666666),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // amount5JP (109:3068)
                                  left: 0,
                                  top: 0,
                                  child: Align(
                                    child: SizedBox(
                                      width: 78,
                                      height: 20,
                                      child: Text(
                                        'AMOUNT',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125,
                                          letterSpacing: 0.96,
                                          color: Color(0xff222222),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogrouptcvuyef (YLEBkhVSTqS9Sqs3sYtCVu)
                            margin: EdgeInsets.fromLTRB(6, 0, 0, 0),
                            width: 318,
                            height: 50,
                            child: Stack(
                              children: [
                                Positioned(
                                  // Jwq (109:3064)
                                  left: 14,
                                  top: 17,
                                  child: Align(
                                    child: SizedBox(
                                      width: 74,
                                      height: 20,
                                      child: Text(
                                        '10500.00',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          height: 1.2125,
                                          letterSpacing: -0.16,
                                          color: Color(0xff438883),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // rectangle23pfH (109:3066)
                                  left: 0,
                                  top: 0,
                                  child: Align(
                                    child: SizedBox(
                                      width: 318,
                                      height: 50,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          border: Border.all(
                                              color: Color(0xff438883)),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group40Krw (222:218)
                      margin: EdgeInsets.fromLTRB(92, 0, 47, 14),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // date4pX (108:249)
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                            child: Text(
                              'DATE',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                height: 1.2125,
                                letterSpacing: 0.96,
                                color: Color(0xff222222),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupkqrsywV (YLEC4GpVLfFBdxKPfMkQrs)
                            width: double.infinity,
                            height: 50,
                            child: Stack(
                              children: [
                                Positioned(
                                  // tue22feb2022iu5 (108:242)
                                  left: 20,
                                  top: 17,
                                  child: Align(
                                    child: SizedBox(
                                      width: 131,
                                      height: 20,
                                      child: Text(
                                        'Tue, 22 Feb 2022',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125,
                                          letterSpacing: -0.16,
                                          color: Color(0xff222222),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // rectangle2117V (108:246)
                                  left: 0,
                                  top: 0,
                                  child: Align(
                                    child: SizedBox(
                                      width: 318,
                                      height: 50,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          border: Border.all(
                                              color: Color(0xffdddddd)),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // iconcalendarinb (108:252)
                                  left: 285,
                                  top: 17,
                                  child: Align(
                                    child: SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: Image.network(""),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // keyboardsnumericiphoneQfR (108:253)
                      margin: EdgeInsets.fromLTRB(43, 0, 0, 0),
                      width: 414,
                      height: 238,
                      child: Container(
                        // keyboardlighthelperw9Z (I108:253;3592:19801)
                        width: double.infinity,
                        height: double.infinity,
                        child: Container(
                          // backgroundkeyboardbgtqV (I108:253;3592:19801;3619:3904)
                          padding: EdgeInsets.fromLTRB(6, 6, 6, 8),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration(
                            color: Color(0xb2cdd1d8),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur(
                                sigmaX: 35,
                                sigmaY: 35,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogrouprdpkMyy (YLECNBUKMKWxCiZ39LrDpK)
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                    width: double.infinity,
                                    height: 46,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // Hsd (I108:253;3592:19801;3592:19686)
                                          padding: EdgeInsets.fromLTRB(
                                              58.5, 0, 59.5, 0),
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Text(
                                            '1',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontSize: 25,
                                              fontWeight: FontWeight.w400,
                                              height: 1.2575,
                                              letterSpacing: -0.5,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // jDq (I108:253;3592:19801;3592:19689)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersFT5 (I108:253;3592:19801;3592:19689;3592:19683)
                                                left: 53,
                                                top: 29,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 23,
                                                    height: 13,
                                                    child: Text(
                                                      'ABC',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // number8Fy (I108:253;3592:19801;3592:19689;3592:19673)
                                                left: 59,
                                                top: 0,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '2',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // bvF (I108:253;3592:19801;3592:19692)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // letterswDR (I108:253;3592:19801;3592:19692;3592:19683)
                                                left: 53,
                                                top: 29,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 23,
                                                    height: 13,
                                                    child: Text(
                                                      'DEF',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // number31Z (I108:253;3592:19801;3592:19692;3592:19673)
                                                left: 58.5,
                                                top: 0,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '3',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupsghuXBd (YLECb1SH3zG5aJ8HK8sghu)
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                    width: double.infinity,
                                    height: 47,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // 3fm (I108:253;3592:19801;3592:19695)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersB1H (I108:253;3592:19801;3592:19695;3592:19683)
                                                left: 47.5,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 22,
                                                    height: 13,
                                                    child: Text(
                                                      'GHI',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numberseo (I108:253;3592:19801;3592:19695;3592:19673)
                                                left: 52.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '4',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // 9MR (I108:253;3592:19801;3592:19696)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersF9Z (I108:253;3592:19801;3592:19696;3592:19683)
                                                left: 53.5,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 22,
                                                    height: 13,
                                                    child: Text(
                                                      'JKL',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numberjqR (I108:253;3592:19801;3592:19696;3592:19673)
                                                left: 59,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '5',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // 23q (I108:253;3592:19801;3592:19697)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersMbu (I108:253;3592:19801;3592:19697;3592:19683)
                                                left: 51,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 27,
                                                    height: 13,
                                                    child: Text(
                                                      'MNO',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // number4WK (I108:253;3592:19801;3592:19697;3592:19673)
                                                left: 58.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '6',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupcmp3x5u (YLECnqRuM9d1pvMcQQCMp3)
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                    width: double.infinity,
                                    height: 47,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // gGo (I108:253;3592:19801;3592:19721)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersQib (I108:253;3592:19801;3592:19721;3592:19683)
                                                left: 42.5,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 32,
                                                    height: 13,
                                                    child: Text(
                                                      'PQRS',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numberJoy (I108:253;3592:19801;3592:19721;3592:19673)
                                                left: 52.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '7',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // Bsm (I108:253;3592:19801;3592:19722)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersVdZ (I108:253;3592:19801;3592:19722;3592:19683)
                                                left: 53,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 23,
                                                    height: 13,
                                                    child: Text(
                                                      'TUV',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numberbAo (I108:253;3592:19801;3592:19722;3592:19673)
                                                left: 58.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '8',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // UVV (I108:253;3592:19801;3592:19723)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersbq1 (I108:253;3592:19801;3592:19723;3592:19683)
                                                left: 48.5,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 32,
                                                    height: 13,
                                                    child: Text(
                                                      'WXYZ',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numbertZD (I108:253;3592:19801;3592:19723;3592:19673)
                                                left: 58.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '9',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupx2vbNjH (YLECzfRXeJyx5YawVfX2vB)
                                    margin:
                                        EdgeInsets.fromLTRB(36, 0, 51.5, 12),
                                    width: double.infinity,
                                    height: 46,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // W4o (I108:253;3592:19801;3592:19760)
                                          margin:
                                              EdgeInsets.fromLTRB(0, 0, 51, 6),
                                          width: 49,
                                          height: 14,
                                          child: Image.network(""),
                                        ),
                                        Container(
                                          // dQK (I108:253;3592:19801;3592:19739)
                                          margin: EdgeInsets.fromLTRB(
                                              0, 0, 61.5, 0),
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            color: Color(0xffffffff),
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x59000000),
                                                offset: Offset(0, 1),
                                                blurRadius: 0,
                                              ),
                                            ],
                                          ),
                                          child: Center(
                                            child: Text(
                                              '0',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 25,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2575,
                                                letterSpacing: -0.5,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // deleteUvj (I108:253;3592:19801;3592:19742)
                                          margin:
                                              EdgeInsets.fromLTRB(0, 0, 0, 2),
                                          width: 23,
                                          height: 17,
                                          child: Image.network(""),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // draggerbEf (I108:253;3592:19801;3592:19761)
                                    margin: EdgeInsets.fromLTRB(133, 0, 134, 0),
                                    width: double.infinity,
                                    height: 5,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group4WsR (108:254)
              left: 32,
              top: 20,
              child: Container(
                width: 327.48,
                height: 16,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timedSF (108:255)
                      margin: EdgeInsets.fromLTRB(0, 0, 240, 0),
                      child: Text(
                        '9:41',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          height: 1.2575,
                          letterSpacing: -0.2399999946,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // group2Y3R (108:256)
                      margin: EdgeInsets.fromLTRB(0, 1, 0, 3),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // combinedshapeUSs (108:257)
                            margin: EdgeInsets.fromLTRB(0, 0, 4.47, 0),
                            width: 16.5,
                            height: 10,
                            child: Image.network(""),
                          ),
                          Container(
                            // combinedshapePpj (108:262)
                            margin: EdgeInsets.fromLTRB(0, 0, 3.95, 0.5),
                            width: 14.05,
                            height: 10,
                            child: Image.network(""),
                          ),
                          Container(
                            // batteryWuM (108:266)
                            width: 26.5,
                            height: 12,
                            child: Image.network(""),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
