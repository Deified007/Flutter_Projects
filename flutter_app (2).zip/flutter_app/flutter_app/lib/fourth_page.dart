import 'package:flutter/material.dart';

class FourthPage extends StatefulWidget {
  const FourthPage({super.key});

  @override
  State<FourthPage> createState() => _FourthPageState();
}

class _FourthPageState extends State<FourthPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: 844,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
        ),
        child: Container(
          width: 524,
          height: 811,
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                child: Container(
                  width: 524,
                  height: 284.5,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 33.799987793,
                        top: 88,
                        child: Align(
                          child: SizedBox(
                            width: 8.4,
                            height: 14,
                            child: Image.network(""),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 524,
                          height: 284.5,
                          child: Stack(
                            children: [
                              Positioned(
                                left: 0.0000305176,
                                top: 0,
                                child: Align(
                                  child: SizedBox(
                                    width: 414,
                                    height: 261.76,
                                    child: Image.network(""),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 0,
                                top: 0,
                                child: Align(
                                  child: SizedBox(
                                    width: 390,
                                    height: 185,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xff429690),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 0,
                                top: 0,
                                child: Align(
                                  child: SizedBox(
                                    width: 390,
                                    height: 220,
                                    child: Image.network(""),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 0,
                                top: 0,
                                child: Align(
                                  child: SizedBox(
                                    width: 322,
                                    height: 241,
                                    child: Image.network(""),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 284,
                                top: 143,
                                child: Align(
                                  child: SizedBox(
                                    width: 79,
                                    height: 25,
                                    child: Text(
                                      'Account',
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 143,
                                top: 143,
                                child: Align(
                                  child: SizedBox(
                                    width: 111,
                                    height: 25,
                                    child: Text(
                                      'Transaction',
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 24,
                                top: 143,
                                child: Align(
                                  child: SizedBox(
                                    width: 90,
                                    height: 25,
                                    child: Text(
                                      'Spending',
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 48,
                                top: 96.3179931641,
                                child: Align(
                                  child: SizedBox(
                                    width: 42,
                                    height: 42.68,
                                    child: Image.network(""),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 171,
                                top: 96,
                                child: Align(
                                  child: SizedBox(
                                    width: 48,
                                    height: 48,
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom(
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Image.network(""),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 300,
                                top: 95,
                                child: Align(
                                  child: SizedBox(
                                    width: 48,
                                    height: 48,
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom(
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Image.network(""),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 0,
                top: 240.5,
                child: Container(
                  padding: EdgeInsets.fromLTRB(137, 23.5, 49, 0),
                  width: 524,
                  height: 526.5,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 3, 285),
                        width: 333,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 1, 35),
                              width: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 140, 1),
                                    child: Text(
                                      'Income',
                                      style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2125,
                                        color: Color(0xff1bcf42),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 1, 0, 0),
                                    child: Text(
                                      '₹10500.00',
                                      style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125,
                                        color: Color(0xff1bcf42),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 1, 23),
                              width: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 139, 0),
                                    child: Text(
                                      'Expense',
                                      style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2125,
                                        color: Color(0xffa92626),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    '₹7952.00',
                                    style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125,
                                      color: Color(0xffa92626),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 0, 8),
                              child: Text(
                                '------------------------------',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125,
                                  color: Color(0xff8c6262),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                              width: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 79, 0),
                                    child: Text(
                                      'Total Balance',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2125,
                                        color: Color(0xff222222),
                                      ),
                                    ),
                                  ),
                                  RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.w700,
                                        height: 1.2102272727,
                                        letterSpacing: -1.1,
                                        color: Color(0xff222222),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: ' ',
                                          style: TextStyle(
                                            fontSize: 22,
                                            fontWeight: FontWeight.w700,
                                            height: 1.2125,
                                            letterSpacing: -1.1,
                                            color: Color(0xff222222),
                                          ),
                                        ),
                                        TextSpan(
                                          text: '₹ ',
                                          style: TextStyle(
                                            fontSize: 22,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2125,
                                            letterSpacing: -1.1,
                                            color: Color(0xff222222),
                                          ),
                                        ),
                                        TextSpan(
                                            text: '2,548.00',
                                            style: TextStyle(
                                              fontSize: 22,
                                              fontWeight: FontWeight.w700,
                                              height: 1.2125,
                                              letterSpacing: -1.1,
                                              color: Color(0xff222222),
                                            )),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                width: double.infinity,
                height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(40),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 18, 0),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom(
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 160,
                          height: double.infinity,
                          decoration: BoxDecoration(
                            color: Color(0xfff30909),
                            borderRadius: BorderRadius.circular(40),
                          ),
                          child: Center(
                            child: Text(
                              '+ Expense',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w600,
                                height: 1.2125,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 160,
                        height: double.infinity,
                        decoration: BoxDecoration(
                          color: Color(0xff1bcf42),
                          borderRadius: BorderRadius.circular(40),
                        ),
                        child: Center(
                          child: Text(
                            '+ Income',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w600,
                              height: 1.2125,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
