import 'dart:ui';

import 'package:flutter/material.dart';

class FifthPage extends StatefulWidget {
  const FifthPage({super.key});

  @override
  State<FifthPage> createState() => _FifthPageState();
}

class _FifthPageState extends State<FifthPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // expenseJYw (98:1843)
        width: double.infinity,
        height: 844,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // group36PKV (222:213)
              left: 0,
              top: 0,
              child: Container(
                width: 461,
                height: 866,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group325y1 (222:209)
                      margin: EdgeInsets.fromLTRB(0, 0, 12, 17),
                      width: 449,
                      height: 309,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: NetworkImage(""),
                        ),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // rectangle23maw (129:3125)
                            left: 6,
                            top: 137,
                            child: Align(
                              child: SizedBox(
                                width: 377,
                                height: 48,
                                child: Image.network(""),
                              ),
                            ),
                          ),
                          Positioned(
                            // frame21sP5 (129:3126)
                            left: 12,
                            top: 141,
                            child: Container(
                              width: 181,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Color(0xffffffff),
                                borderRadius: BorderRadius.circular(40),
                              ),
                              child: Center(
                                child: Text(
                                  'Expense',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2125,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // incomeKF5 (129:3128)
                            left: 250,
                            top: 149,
                            child: Align(
                              child: SizedBox(
                                width: 73,
                                height: 25,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom(
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Text(
                                    'Income',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w700,
                                      height: 1.2125,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group6yaX (109:3075)
                            left: 0,
                            top: 0,
                            child: Align(
                              child: SizedBox(
                                width: 269.4,
                                height: 219,
                                child: Image.network(""),
                              ),
                            ),
                          ),
                          Positioned(
                            // iconchevronleftV35 (98:1850)
                            left: 21,
                            top: 81,
                            child: Align(
                              child: SizedBox(
                                width: 28,
                                height: 28,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom(
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.network(""),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group339tK (222:210)
                      margin: EdgeInsets.fromLTRB(96, 0, 42, 35),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // categoryHDq (98:1862)
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 9),
                            child: Text(
                              'CATEGORY',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                height: 1.2125,
                                letterSpacing: 0.96,
                                color: Color(0xff222222),
                              ),
                            ),
                          ),
                          Container(
                            // autogroup8uabxqm (YLE9MmUw8RFVnD8r1y8Uab)
                            margin: EdgeInsets.fromLTRB(5, 0, 0, 0),
                            width: 318,
                            height: 50,
                            child: Stack(
                              children: [
                                Positioned(
                                  // netflixsxj (98:1852)
                                  left: 21,
                                  top: 16,
                                  child: Align(
                                    child: SizedBox(
                                      width: 49,
                                      height: 20,
                                      child: Text(
                                        'Netflix',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125,
                                          letterSpacing: -0.16,
                                          color: Color(0xff222222),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // rectangle19AS3 (98:1855)
                                  left: 0,
                                  top: 0,
                                  child: Align(
                                    child: SizedBox(
                                      width: 318,
                                      height: 50,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          border: Border.all(
                                              color: Color(0xffdddddd)),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group34TR9 (222:211)
                      margin: EdgeInsets.fromLTRB(96, 0, 41, 24),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // amountnTR (98:1863)
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                            child: Text(
                              'AMOUNT',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                height: 1.2125,
                                letterSpacing: 0.96,
                                color: Color(0xff222222),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupqzoq6yu (YLE9VBSFPG1FaxGPBPqzoq)
                            margin: EdgeInsets.fromLTRB(6, 0, 0, 0),
                            width: 318,
                            height: 50,
                            child: Stack(
                              children: [
                                Positioned(
                                  // RmH (98:1853)
                                  left: 14,
                                  top: 17,
                                  child: Align(
                                    child: SizedBox(
                                      width: 61,
                                      height: 20,
                                      child: Text(
                                        '1100.00',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          height: 1.2125,
                                          letterSpacing: -0.16,
                                          color: Color(0xff438883),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // rectangle2089u (98:1857)
                                  left: 0,
                                  top: 0,
                                  child: Align(
                                    child: SizedBox(
                                      width: 318,
                                      height: 50,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          border: Border.all(
                                              color: Color(0xff438883)),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group353Xm (222:212)
                      margin: EdgeInsets.fromLTRB(96, 0, 42, 14),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // dateb3V (98:1864)
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                            child: Text(
                              'DATE',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                height: 1.2125,
                                letterSpacing: 0.96,
                                color: Color(0xff222222),
                              ),
                            ),
                          ),
                          Container(
                            // autogrouphjx1Hwu (YLEBG8Ui8SQzwEdeDvHJX1)
                            margin: EdgeInsets.fromLTRB(5, 0, 0, 0),
                            width: 318,
                            height: 50,
                            child: Stack(
                              children: [
                                Positioned(
                                  // tue22feb2022D4s (98:1854)
                                  left: 15,
                                  top: 17,
                                  child: Align(
                                    child: SizedBox(
                                      width: 131,
                                      height: 20,
                                      child: Text(
                                        'Tue, 22 Feb 2022',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2125,
                                          letterSpacing: -0.16,
                                          color: Color(0xff222222),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // iconcalendar6uM (98:1869)
                                  left: 280,
                                  top: 17,
                                  child: Align(
                                    child: SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: Image.network(""),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // rectangle25oom (148:1821)
                                  left: 0,
                                  top: 0,
                                  child: Align(
                                    child: SizedBox(
                                      width: 318,
                                      height: 50,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          border: Border.all(
                                              color: Color(0xffdddddd)),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // keyboardsnumericiphone85M (98:1870)
                      margin: EdgeInsets.fromLTRB(47, 0, 0, 0),
                      width: 414,
                      height: 238,
                      child: Container(
                        // keyboardlighthelperFv (I98:1870;3592:19801)
                        width: double.infinity,
                        height: double.infinity,
                        child: Container(
                          // backgroundkeyboardbgR4T (I98:1870;3592:19801;3619:3904)
                          padding: EdgeInsets.fromLTRB(6, 6, 6, 8),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration(
                            color: Color(0xb2cdd1d8),
                          ),
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ImageFilter.blur(
                                sigmaX: 35,
                                sigmaY: 35,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupdrefVKD (YLE9mLdzSHMgh3egGxDReF)
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                    width: double.infinity,
                                    height: 46,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // bt3 (I98:1870;3592:19801;3592:19686)
                                          padding: EdgeInsets.fromLTRB(
                                              58.5, 0, 59.5, 0),
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Text(
                                            '1',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontSize: 25,
                                              fontWeight: FontWeight.w400,
                                              height: 1.2575,
                                              letterSpacing: -0.5,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // Sdm (I98:1870;3592:19801;3592:19689)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersaEB (I98:1870;3592:19801;3592:19689;3592:19683)
                                                left: 53,
                                                top: 29,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 23,
                                                    height: 13,
                                                    child: Text(
                                                      'ABC',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numberFr7 (I98:1870;3592:19801;3592:19689;3592:19673)
                                                left: 59,
                                                top: 0,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '2',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // jWP (I98:1870;3592:19801;3592:19692)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // letterss6o (I98:1870;3592:19801;3592:19692;3592:19683)
                                                left: 53,
                                                top: 29,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 23,
                                                    height: 13,
                                                    child: Text(
                                                      'DEF',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numberALo (I98:1870;3592:19801;3592:19692;3592:19673)
                                                left: 58.5,
                                                top: 0,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '3',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupnrjzTqh (YLEA35gm51dhq5JqknnrjZ)
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                    width: double.infinity,
                                    height: 47,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // bS7 (I98:1870;3592:19801;3592:19695)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersvjH (I98:1870;3592:19801;3592:19695;3592:19683)
                                                left: 47.5,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 22,
                                                    height: 13,
                                                    child: Text(
                                                      'GHI',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // number2GX (I98:1870;3592:19801;3592:19695;3592:19673)
                                                left: 52.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '4',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // htT (I98:1870;3592:19801;3592:19696)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersSr3 (I98:1870;3592:19801;3592:19696;3592:19683)
                                                left: 53.5,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 22,
                                                    height: 13,
                                                    child: Text(
                                                      'JKL',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numberwno (I98:1870;3592:19801;3592:19696;3592:19673)
                                                left: 59,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '5',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // 3L3 (I98:1870;3592:19801;3592:19697)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersP91 (I98:1870;3592:19801;3592:19697;3592:19683)
                                                left: 51,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 27,
                                                    height: 13,
                                                    child: Text(
                                                      'MNO',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numbert5m (I98:1870;3592:19801;3592:19697;3592:19673)
                                                left: 58.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '6',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupquxjNmd (YLEAGf8UKouyYNPXEUquxj)
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                    width: double.infinity,
                                    height: 47,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // i4o (I98:1870;3592:19801;3592:19721)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // letterseU (I98:1870;3592:19801;3592:19721;3592:19683)
                                                left: 42.5,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 32,
                                                    height: 13,
                                                    child: Text(
                                                      'PQRS',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numberjkb (I98:1870;3592:19801;3592:19721;3592:19673)
                                                left: 52.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '7',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // pn3 (I98:1870;3592:19801;3592:19722)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersmBV (I98:1870;3592:19801;3592:19722;3592:19683)
                                                left: 53,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 23,
                                                    height: 13,
                                                    child: Text(
                                                      'TUV',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numberU5u (I98:1870;3592:19801;3592:19722;3592:19673)
                                                left: 58.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '8',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          // M9h (I98:1870;3592:19801;3592:19723)
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(""),
                                            ),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // lettersUVD (I98:1870;3592:19801;3592:19723;3592:19683)
                                                left: 48.5,
                                                top: 30,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 32,
                                                    height: 13,
                                                    child: Text(
                                                      'WXYZ',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        height: 1.2575,
                                                        letterSpacing: 1.7,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // numbermUK (I98:1870;3592:19801;3592:19723;3592:19673)
                                                left: 58.5,
                                                top: 1,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12,
                                                    height: 32,
                                                    child: Text(
                                                      '9',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 25,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.2575,
                                                        letterSpacing: -0.5,
                                                        color:
                                                            Color(0xff000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroup6yso3Rq (YLEAVpRDAK7qHbk56T6ySo)
                                    margin:
                                        EdgeInsets.fromLTRB(36, 0, 51.5, 12),
                                    width: double.infinity,
                                    height: 46,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // xoh (I98:1870;3592:19801;3592:19760)
                                          margin:
                                              EdgeInsets.fromLTRB(0, 0, 51, 6),
                                          width: 49,
                                          height: 14,
                                          child: Image.network(""),
                                        ),
                                        Container(
                                          // gjh (I98:1870;3592:19801;3592:19739)
                                          margin: EdgeInsets.fromLTRB(
                                              0, 0, 61.5, 0),
                                          width: 130,
                                          height: double.infinity,
                                          decoration: BoxDecoration(
                                            color: Color(0xffffffff),
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x59000000),
                                                offset: Offset(0, 1),
                                                blurRadius: 0,
                                              ),
                                            ],
                                          ),
                                          child: Center(
                                            child: Text(
                                              '0',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 25,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2575,
                                                letterSpacing: -0.5,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // deletejT5 (I98:1870;3592:19801;3592:19742)
                                          margin:
                                              EdgeInsets.fromLTRB(0, 0, 0, 2),
                                          width: 23,
                                          height: 17,
                                          child: Image.network(""),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // draggerT8B (I98:1870;3592:19801;3592:19761)
                                    margin: EdgeInsets.fromLTRB(133, 0, 134, 0),
                                    width: double.infinity,
                                    height: 5,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group4AoH (98:1875)
              left: 28.782043457,
              top: 20,
              child: Container(
                width: 330.18,
                height: 16,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeV4s (98:1876)
                      margin: EdgeInsets.fromLTRB(0, 0, 242.36, 0),
                      child: Text(
                        '9:41',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          height: 1.2575,
                          letterSpacing: -0.2399999946,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // group2o5Z (98:1877)
                      margin: EdgeInsets.fromLTRB(0, 1, 0, 3),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // combinedshape8tX (98:1878)
                            margin: EdgeInsets.fromLTRB(0, 0, 4.51, 0),
                            width: 16.65,
                            height: 10,
                            child: Image.network(""),
                          ),
                          Container(
                            // combinedshapeFy9 (98:1883)
                            margin: EdgeInsets.fromLTRB(0, 0, 3.99, 0.5),
                            width: 14.18,
                            height: 10,
                            child: Image.network(""),
                          ),
                          Container(
                            // batteryb1R (98:1887)
                            width: 26.5,
                            height: 12,
                            child: Image.network(""),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
