import 'package:flutter/material.dart';

class EightPage extends StatefulWidget {
  const EightPage({super.key});

  @override
  State<EightPage> createState() => _EightPageState();
}

class _EightPageState extends State<EightPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // dataQVm (8:1672)
        padding: EdgeInsets.fromLTRB(0, 0, 0, 359),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group45HJf (222:224)
              margin: EdgeInsets.fromLTRB(0, 0, 0, 26),
              width: 445,
              height: 242,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle1bKM (8:1702)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 179,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0x2b000000)),
                            color: Color(0xff429690),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle2261D (110:1754)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 220,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // group61dy (109:3095)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 267,
                        height: 219,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // accountJsy (8:1703)
                    left: 284,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 79,
                        height: 25,
                        child: Text(
                          'Account',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // transactionxxX (8:1704)
                    left: 143,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 111,
                        height: 25,
                        child: Text(
                          'Transaction',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // spendingGTR (8:1708)
                    left: 24,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 90,
                        height: 25,
                        child: Text(
                          'Spending',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // tdesignmoneynAs (8:1711)
                    left: 48,
                    top: 96.3179931641,
                    child: Align(
                      child: SizedBox(
                        width: 42,
                        height: 42.68,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // grommeticonstransaction6ST (8:1714)
                    left: 175,
                    top: 100,
                    child: Align(
                      child: SizedBox(
                        width: 40,
                        height: 40,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // mdiaccountsgroup1ZR (8:1716)
                    left: 300,
                    top: 106,
                    child: Align(
                      child: SizedBox(
                        width: 48,
                        height: 29,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // phplusfilliij (8:1725)
                    left: 350.25,
                    top: 55.25,
                    child: Align(
                      child: SizedBox(
                        width: 25.5,
                        height: 25.5,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // group4dqh (103:2859)
                    left: 32,
                    top: 20,
                    child: Container(
                      width: 327.26,
                      height: 16,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timekvK (103:2860)
                            margin: EdgeInsets.fromLTRB(0, 0, 244.44, 0),
                            child: Text(
                              '9:41',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                height: 1.2575,
                                letterSpacing: -0.2399999946,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // group2FMH (103:2861)
                            margin: EdgeInsets.fromLTRB(0, 1, 0, 3),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // combinedshapePCb (103:2862)
                                  margin: EdgeInsets.fromLTRB(0, 0, 4.17, 0),
                                  width: 15.37,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // combinedshapeHom (103:2867)
                                  margin: EdgeInsets.fromLTRB(0, 0, 1.68, 0.5),
                                  width: 13.09,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // batteryQdV (103:2871)
                                  width: 26.5,
                                  height: 12,
                                  child: Image.network(""),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle23M2w (143:1739)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 179,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0x2b000000)),
                            color: Color(0xff429690),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle24fJX (143:1740)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 220,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // group10wfM (143:1741)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 267,
                        height: 219,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // accountSc7 (143:1745)
                    left: 284,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 79,
                        height: 25,
                        child: Text(
                          'Account',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // transaction8zj (143:1746)
                    left: 143,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 111,
                        height: 25,
                        child: Text(
                          'Transaction',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // spendingqeF (143:1747)
                    left: 24,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 90,
                        height: 25,
                        child: Text(
                          'Spending',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // tdesignmoneyvvb (143:1748)
                    left: 45,
                    top: 95,
                    child: Align(
                      child: SizedBox(
                        width: 48,
                        height: 48,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.network(""),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // grommeticonstransactionRMZ (143:1751)
                    left: 175,
                    top: 100,
                    child: Align(
                      child: SizedBox(
                        width: 40,
                        height: 40,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // mdiaccountsgroupWdu (143:1753)
                    left: 300,
                    top: 95,
                    child: Align(
                      child: SizedBox(
                        width: 48,
                        height: 48,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.network(""),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // phplusfillod1 (143:1755)
                    left: 320,
                    top: 51,
                    child: Align(
                      child: SizedBox(
                        width: 34,
                        height: 34,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.network(""),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group11tuM (143:1757)
                    left: 32,
                    top: 20,
                    child: Container(
                      width: 327.26,
                      height: 16,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timep2K (143:1758)
                            margin: EdgeInsets.fromLTRB(0, 0, 244.44, 0),
                            child: Text(
                              '9:41',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                height: 1.2575,
                                letterSpacing: -0.2399999946,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // group2vb9 (143:1759)
                            margin: EdgeInsets.fromLTRB(0, 1, 0, 3),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // combinedshapeTb5 (143:1760)
                                  margin: EdgeInsets.fromLTRB(0, 0, 4.17, 0),
                                  width: 15.37,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // combinedshapeAVV (143:1765)
                                  margin: EdgeInsets.fromLTRB(0, 0, 1.68, 0.5),
                                  width: 13.09,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // batteryhEX (143:1769)
                                  width: 26.5,
                                  height: 12,
                                  child: Image.network(""),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group442nb (222:222)
              margin: EdgeInsets.fromLTRB(43, 0, 40, 0),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroupm1hzmEP (YLEEKshshhHm6FrtH4M1hZ)
                    margin: EdgeInsets.fromLTRB(1, 0, 0, 0),
                    width: double.infinity,
                    height: 41,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // group96XZ (110:1725)
                          margin: EdgeInsets.fromLTRB(0, 0, 178, 0),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // upstoxSLX (110:1726)
                                margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                child: Text(
                                  'UPSTOX',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.32,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Text(
                                // todayw2P (110:1727)
                                'TODAY',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125,
                                  letterSpacing: -0.26,
                                  color: Color(0xff666666),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // UY7 (110:1728)
                          margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                          child: Text(
                            '+ 850.00',
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              height: 1.2125,
                              letterSpacing: -0.72,
                              color: Color(0xff24a869),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  ),
                  Container(
                    // autogroupble3yzf (YLEETTKaXTGt5pt5HaBLE3)
                    margin: EdgeInsets.fromLTRB(1, 0, 0, 0),
                    width: double.infinity,
                    height: 41,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // group96Jb (110:1734)
                          margin: EdgeInsets.fromLTRB(0, 0, 163, 0),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // transferEQo (110:1735)
                                margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                child: Text(
                                  'TRANSFER',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.32,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Text(
                                // yesterdaywKD (110:1736)
                                'YESTERDAY',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125,
                                  letterSpacing: -0.26,
                                  color: Color(0xff666666),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // U4F (110:1749)
                          margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                          child: Text(
                            '- 6552.00',
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              height: 1.2125,
                              letterSpacing: -0.72,
                              color: Color(0xfff95b51),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  ),
                  Container(
                    // autogroupytzzmZ9 (YLEEaNHj5YLYL6LeujYTZZ)
                    margin: EdgeInsets.fromLTRB(1, 0, 0, 0),
                    width: double.infinity,
                    height: 41,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group97N7 (110:1740)
                          margin: EdgeInsets.fromLTRB(0, 0, 139, 0),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // growwrab (110:1741)
                                margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                child: Text(
                                  'GROWW',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.32,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Text(
                                // aug302023nDM (110:1742)
                                'AUG 30, 2023',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125,
                                  letterSpacing: -0.26,
                                  color: Color(0xff666666),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // v4f (110:1750)
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 3),
                          child: Text(
                            '+ 9650.00',
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              height: 1.2125,
                              letterSpacing: -0.72,
                              color: Color(0xff24a869),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  ),
                  Container(
                    // autogroupspi7pQw (YLEEgccKMxUjq4Ed9YSPi7)
                    margin: EdgeInsets.fromLTRB(0, 0, 2, 0),
                    width: double.infinity,
                    height: 41,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // group9kJb (110:1746)
                          margin: EdgeInsets.fromLTRB(0, 0, 147, 0),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // youtubefgT (110:1747)
                                margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                child: Text(
                                  'YOUTUBE',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.32,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Text(
                                // aug162023aHd (110:1748)
                                'AUG 16, 2023',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125,
                                  letterSpacing: -0.26,
                                  color: Color(0xff666666),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // JUX (110:1751)
                          margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                          child: Text(
                            '- 1400.00',
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              height: 1.2125,
                              letterSpacing: -0.72,
                              color: Color(0xfff95b51),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
