import 'dart:ui';

import 'package:flutter/material.dart';

class NinthPage extends StatefulWidget {
  const NinthPage({super.key});

  @override
  State<NinthPage> createState() => _NinthPageState();
}

class _NinthPageState extends State<NinthPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // profilerxP (101:2721)
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // group46xkX (222:225)
              width: 445,
              height: 242,
              decoration: BoxDecoration(
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage(""),
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // group4eNT (143:1664)
                    left: 32,
                    top: 20,
                    child: Container(
                      width: 327.26,
                      height: 16,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timeZVR (143:1665)
                            margin: EdgeInsets.fromLTRB(0, 0, 244.44, 0),
                            child: Text(
                              '9:41',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                height: 1.2575,
                                letterSpacing: -0.2399999946,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // group2F7M (143:1666)
                            margin: EdgeInsets.fromLTRB(0, 1, 0, 3),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // combinedshapeyZ9 (143:1667)
                                  margin: EdgeInsets.fromLTRB(0, 0, 4.17, 0),
                                  width: 15.37,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // combinedshapegyM (143:1672)
                                  margin: EdgeInsets.fromLTRB(0, 0, 1.68, 0.5),
                                  width: 13.09,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // batteryQuM (143:1676)
                                  width: 26.5,
                                  height: 12,
                                  child: Image.network(""),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // iconchevronleft9M9 (101:2724)
                    left: 33.799987793,
                    top: 88,
                    child: Align(
                      child: SizedBox(
                        width: 8.4,
                        height: 14,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // group6Sr3 (101:2725)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 267,
                        height: 219,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame229VZ (137:1774)
                    left: 105,
                    top: 102,
                    child: Container(
                      width: 180,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(40),
                      ),
                      child: Center(
                        child: Text(
                          'Account',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            height: 1.2125,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1ce3 (143:1775)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 179,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0x2b000000)),
                            color: Color(0xff429690),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle22vPq (143:1776)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 220,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // group14RrP (143:1777)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 267,
                        height: 219,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // accountXPd (143:1781)
                    left: 284,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 79,
                        height: 25,
                        child: Text(
                          'Account',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // transactionE39 (143:1782)
                    left: 143,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 111,
                        height: 25,
                        child: Text(
                          'Transaction',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // spendingY3q (143:1783)
                    left: 24,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 90,
                        height: 25,
                        child: Text(
                          'Spending',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // tdesignmoneySuu (143:1784)
                    left: 48,
                    top: 96.3179931641,
                    child: Align(
                      child: SizedBox(
                        width: 42,
                        height: 42.68,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // grommeticonstransactionx7Z (143:1787)
                    left: 175,
                    top: 100,
                    child: Align(
                      child: SizedBox(
                        width: 40,
                        height: 40,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // mdiaccountsgroupfnf (143:1789)
                    left: 300,
                    top: 106,
                    child: Align(
                      child: SizedBox(
                        width: 48,
                        height: 29,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // phplusfillyoM (143:1791)
                    left: 350.25,
                    top: 55.25,
                    child: Align(
                      child: SizedBox(
                        width: 25.5,
                        height: 25.5,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // group15hDZ (143:1793)
                    left: 32,
                    top: 20,
                    child: Container(
                      width: 327.26,
                      height: 16,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timepoy (143:1794)
                            margin: EdgeInsets.fromLTRB(0, 0, 244.44, 0),
                            child: Text(
                              '9:41',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                height: 1.2575,
                                letterSpacing: -0.2399999946,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // group2LGX (143:1795)
                            margin: EdgeInsets.fromLTRB(0, 1, 0, 3),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // combinedshapefpb (143:1796)
                                  margin: EdgeInsets.fromLTRB(0, 0, 4.17, 0),
                                  width: 15.37,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // combinedshapenuD (143:1801)
                                  margin: EdgeInsets.fromLTRB(0, 0, 1.68, 0.5),
                                  width: 13.09,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // battery6uu (143:1805)
                                  width: 26.5,
                                  height: 12,
                                  child: Image.network(""),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle2334T (143:1811)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 179,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0x2b000000)),
                            color: Color(0xff429690),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle28911 (143:1812)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 220,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // group16rAK (143:1813)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 267,
                        height: 219,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // accountMcs (143:1817)
                    left: 284,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 79,
                        height: 25,
                        child: Text(
                          'Account',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // transactionSuD (143:1818)
                    left: 143,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 111,
                        height: 25,
                        child: Text(
                          'Transaction',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // spending9Hq (143:1819)
                    left: 24,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 90,
                        height: 25,
                        child: Text(
                          'Spending',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // tdesignmoneyT3d (143:1820)
                    left: 45,
                    top: 95,
                    child: Align(
                      child: SizedBox(
                        width: 48,
                        height: 48,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.network(""),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // grommeticonstransactionYKy (143:1823)
                    left: 171,
                    top: 96,
                    child: Align(
                      child: SizedBox(
                        width: 48,
                        height: 48,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.network(""),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // mdiaccountsgroupEib (143:1825)
                    left: 300,
                    top: 106,
                    child: Align(
                      child: SizedBox(
                        width: 48,
                        height: 29,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // phplusfilljQT (143:1827)
                    left: 320,
                    top: 51,
                    child: Align(
                      child: SizedBox(
                        width: 34,
                        height: 34,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.network(""),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group17qTV (143:1829)
                    left: 32,
                    top: 20,
                    child: Container(
                      width: 327.26,
                      height: 16,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timekqM (143:1830)
                            margin: EdgeInsets.fromLTRB(0, 0, 244.44, 0),
                            child: Text(
                              '9:41',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                height: 1.2575,
                                letterSpacing: -0.2399999946,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // group2sf5 (143:1831)
                            margin: EdgeInsets.fromLTRB(0, 1, 0, 3),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // combinedshapeccf (143:1832)
                                  margin: EdgeInsets.fromLTRB(0, 0, 4.17, 0),
                                  width: 15.37,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // combinedshapew99 (143:1837)
                                  margin: EdgeInsets.fromLTRB(0, 0, 1.68, 0.5),
                                  width: 13.09,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // batteryFfd (143:1841)
                                  width: 26.5,
                                  height: 12,
                                  child: Image.network(""),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupycsqzdD (YLEGcE51crsUtGupCeyCsq)
              padding: EdgeInsets.fromLTRB(22, 39, 16, 97),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group51LBH (224:230)
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 139),
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // group47G4w (223:226)
                          width: double.infinity,
                          height: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // nameyzw (143:1719)
                                margin: EdgeInsets.fromLTRB(0, 0, 52, 0),
                                child: Text(
                                  'NAME',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.36,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupnfwxUwh (YLEGqUBwjph2DvDBzAnfWX)
                                padding: EdgeInsets.fromLTRB(20, 16, 20, 14),
                                width: 251,
                                height: double.infinity,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff000000)),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  'User',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.16,
                                    color: Color(0xff222222),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 37,
                        ),
                        Container(
                          // group48Xuy (223:227)
                          margin: EdgeInsets.fromLTRB(0, 0, 2, 0),
                          width: double.infinity,
                          height: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // mobilefFV (143:1728)
                                margin: EdgeInsets.fromLTRB(0, 0, 43, 0),
                                child: Text(
                                  'MOBILE',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.36,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupssfhn5D (YLEHCHvagYVgZ8XknCSSfh)
                                padding: EdgeInsets.fromLTRB(22, 14, 22, 16),
                                width: 251,
                                height: double.infinity,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff666666)),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  'xxxxxxxxxx',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.16,
                                    color: Color(0xff222222),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 37,
                        ),
                        Container(
                          // group49SQf (223:228)
                          width: double.infinity,
                          height: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // emailmhq (143:1732)
                                margin: EdgeInsets.fromLTRB(0, 0, 56, 0),
                                child: Text(
                                  'EMAIL',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.36,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupppsxGeb (YLEGxiUsRkDQqqT5JWPPSX)
                                padding: EdgeInsets.fromLTRB(20, 15, 20, 15),
                                width: 251,
                                height: double.infinity,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff666666)),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  'xyz@gmail.com',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.16,
                                    color: Color(0xff222222),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 37,
                        ),
                        Container(
                          // group508Ru (223:229)
                          width: double.infinity,
                          height: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // professionfRq (143:1848)
                                margin: EdgeInsets.fromLTRB(0, 0, 13, 0),
                                child: Text(
                                  'PROFESSION',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.36,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroup5klbBQB (YLEH5NxS8TS2Js5BA35KLB)
                                padding: EdgeInsets.fromLTRB(20, 15, 20, 15),
                                width: 251,
                                height: double.infinity,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff666666)),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  'xyz',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2125,
                                    letterSpacing: -0.16,
                                    color: Color(0xff222222),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // buttonT6o (102:2903)
                    margin: EdgeInsets.fromLTRB(25, 0, 32, 0),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                      ),
                      child: ClipRect(
                        child: BackdropFilter(
                          filter: ImageFilter.blur(
                            sigmaX: 45,
                            sigmaY: 45,
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(117.5, 13, 91.5, 1),
                            width: double.infinity,
                            height: 38,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              border: Border(),
                              gradient: LinearGradient(
                                begin: Alignment(-1, -1),
                                end: Alignment(1.068, 1),
                                colors: <Color>[
                                  Color(0xffd4bc78),
                                  Color(0xffcfa01c)
                                ],
                                stops: <double>[0, 1],
                              ),
                            ),
                            child: Container(
                              // frame3FHZ (I102:2903;252:1575)
                              width: double.infinity,
                              height: double.infinity,
                              child: Center(
                                child: Text(
                                  'Log Out',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    height: 0.75,
                                    color: Color(0xffe1fae5),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
