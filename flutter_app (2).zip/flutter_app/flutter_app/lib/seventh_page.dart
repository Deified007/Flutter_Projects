import 'package:flutter/material.dart';

class SeventhPage extends StatefulWidget {
  const SeventhPage({super.key});

  @override
  State<SeventhPage> createState() => _SeventhPageState();
}

class _SeventhPageState extends State<SeventhPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // transactionDM9 (8:1604)
        padding: EdgeInsets.fromLTRB(0, 0, 0, 246),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group42JNb (222:220)
              margin: EdgeInsets.fromLTRB(0, 0, 0, 194),
              width: 445,
              height: 242,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle1pbq (8:1605)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 179,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0x2b000000)),
                            color: Color(0xff429690),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle22udH (110:1753)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 390,
                        height: 220,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // group62C7 (109:3099)
                    left: 0,
                    top: 0,
                    child: Align(
                      child: SizedBox(
                        width: 267,
                        height: 219,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // accountKwu (8:1606)
                    left: 284,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 79,
                        height: 25,
                        child: Text(
                          'Account',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // transactionb8j (8:1607)
                    left: 143,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 111,
                        height: 25,
                        child: Text(
                          'Transaction',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // spendingttX (8:1613)
                    left: 24,
                    top: 143,
                    child: Align(
                      child: SizedBox(
                        width: 90,
                        height: 25,
                        child: Text(
                          'Spending',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2125,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // tdesignmoneyCeK (8:1616)
                    left: 45,
                    top: 95,
                    child: Align(
                      child: SizedBox(
                        width: 48,
                        height: 48,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.network(""),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // grommeticonstransactiongpP (8:1619)
                    left: 175,
                    top: 100,
                    child: Align(
                      child: SizedBox(
                        width: 40,
                        height: 40,
                        child: Image.network(""),
                      ),
                    ),
                  ),
                  Positioned(
                    // mdiaccountsgroupo8K (8:1621)
                    left: 300,
                    top: 95,
                    child: Align(
                      child: SizedBox(
                        width: 48,
                        height: 48,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.network(""),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // phplusfilluBM (8:1640)
                    left: 320,
                    top: 51,
                    child: Align(
                      child: SizedBox(
                        width: 34,
                        height: 34,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.network(""),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group4bps (103:2877)
                    left: 32,
                    top: 20,
                    child: Container(
                      width: 327.26,
                      height: 16,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // timeXTd (103:2878)
                            margin: EdgeInsets.fromLTRB(0, 0, 244.44, 0),
                            child: Text(
                              '9:41',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                height: 1.2575,
                                letterSpacing: -0.2399999946,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // group23Ry (103:2879)
                            margin: EdgeInsets.fromLTRB(0, 1, 0, 3),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // combinedshapenPZ (103:2880)
                                  margin: EdgeInsets.fromLTRB(0, 0, 4.17, 0),
                                  width: 15.37,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // combinedshapetxP (103:2885)
                                  margin: EdgeInsets.fromLTRB(0, 0, 1.68, 0.5),
                                  width: 13.09,
                                  height: 10,
                                  child: Image.network(""),
                                ),
                                Container(
                                  // batterypr3 (103:2889)
                                  width: 26.5,
                                  height: 12,
                                  child: Image.network(""),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group43Af1 (222:221)
              margin: EdgeInsets.fromLTRB(51, 0, 53, 0),
              padding: EdgeInsets.fromLTRB(26, 46, 28, 47),
              width: double.infinity,
              height: 184,
              decoration: BoxDecoration(
                color: Color(0xff429690),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Center(
                // presstheicontoaddyourfirsttran (8:1642)
                child: SizedBox(
                  child: Container(
                    constraints: BoxConstraints(
                      maxWidth: 232,
                    ),
                    child: Text(
                      'Press the "+" icon to add your first transaction\n',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.w400,
                        height: 1.2125,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
